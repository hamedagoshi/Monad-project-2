# MONAD — Phase 2: Daily Experience MVP

Date: 2026-11-05 · Principle: Observe. Record. Understand. One observation a day.

## 1. What was built

Five entities and one server-side service. No import, no broker, no EA, no analytics,
no scoring, no prediction, no notifications, no social features, no extra entity.

### Entities and relations

```
UserProfile (Phase 1, unchanged)
   │  owner_id
   ▼
DailyRecord  (owner_id, record_date, title, general_note, created_at, updated_at)
   │  1 : N   via daily_record_id
   ├── StateObservation  (observed_at, state_category, description, intensity)
   ├── LifeEvent         (event_time, title, description, category)   [daily_record_id optional]
   ├── TradingSession    (start_time, end_time, market, note)
   └── Reflection        (question, response, created_at, updated_at)
```

Rule enforced: **one DailyRecord per owner per calendar date**. A second `day.upsert` for the
same date updates the existing row and returns `created:false`; a `record_date` clash on
update returns `409 date_conflict`. This is an application rule, not a database constraint
(no index API exists), and the residual race is documented.

`record_date` (`YYYY-MM-DD`) is stored separately from every timestamp, so a calendar day can
never be shifted by a timezone change. Timestamps are stored as ISO-8601 with an offset.

## 2. Data security policy per entity

| Entity | owner_id source | Read | Create | Update | Delete | Parent check |
|---|---|---|---|---|---|---|
| DailyRecord | session (`auth.me().id`) | own rows only (`filter` + post-filter) | own | own id only, resolved through the owner-scoped query | own id only, requires `confirm:true` | n/a |
| StateObservation | session | own rows of own day | parent day must belong to caller, else 404 | child owner + id must match, else 404 | same | yes |
| LifeEvent | session | same | same | same | same | yes |
| TradingSession | session | same | same | same | same | yes |
| Reflection | session | same | same | same | same | yes |

A client-supplied `owner_id` that differs from the session owner is rejected with
`403 ownership_spoof_rejected` before any query runs, on every action.

Deleting a day requires an explicit confirmation and cascades to the five child collections;
without `confirm:true` the service returns `409 confirmation_required` **with the child counts**,
so the UI can state exactly what will be removed. Orphans are therefore impossible by design.

## 3. Backend behaviour, executed against the deployed function

| # | Test | Result |
|---|---|---|
| 1 | Create day (2026-11-05) | 200, `created:true`, id `6aec821e…` |
| 2 | Second upsert, same date | 200, `created:false`, same row |
| 3 | Create observation ×2 (mental, physical) | 200 ×2 |
| 4 | Create life event | 200 |
| 5 | Create trading session | 200 |
| 6 | Create reflection | 200 |
| 7 | Read day | 200, all four collections returned |
| 8 | Edit one observation | 200, `updated_date` changed |
| 9 | Delete one observation | 200, the other sections untouched |
| 10 | Timeline | 200, five items ordered by stored time |
| 11 | Calendar (Oct–Nov) | 200, one marked day with counts |
| 12 | Delete day without confirm | **409** with child counts |
| 13 | Delete day with confirm | 200, cascade removed 1 child, day gone |
| 14 | No orphan after cascade | PASS, `LifeEvent` count = 1 (the untouched day) |
| 15 | Attach child to a foreign/absent day | **404** |
| 16 | Forged `owner_id` | **403** |
| 17 | End before start | **422** with field error |

## 4. UI, executed in the harness

Route set: `/` (Today), `/journal`, `/day/:date`, `/timeline`, `/calendar`, `/settings`, plus the
protected shell. 84 route/breakpoint combinations and 9 interaction flows were executed:

| Dimension | Values |
|---|---|
| Widths | 360, 390, 412, 768, 1280 |
| Language / direction | fa-RTL, en-LTR |
| Theme | dark, light |
| Routes per combination | 6 |

| Metric | Result |
|---|---|
| Horizontal overflow | **0 combinations** (was 6 before the fix) |
| Interactive targets under 44px | **0** (was 56 rows) |
| Unexpected visible error banners | **0** |
| Wrong `dir` for language | **0** (was 24 rows) |
| Routes rendering the correct heading | 6/6 in every combination |

Interaction flows: empty-day state, save note, create observation, edit observation, delete
observation, reflection surviving an unrelated delete, persistence after a full page reload,
network-failure state, calendar rendering while the API is failing — **9/9 PASS**.

### Honest boundary
The UI harness runs the routing double and an in-memory fixture store, not the production
database. It proves rendering, layout, direction, target size, state handling and error
handling. It does **not** prove data persistence against the platform; that is proven
separately by tests 1–17 above against the deployed function. Fixture mode is guarded to
localhost + `?fixtures=1` and must be deleted before release.

## 5. Defects found and fixed (each retested)

| # | Defect | Fix | Retest |
|---|---|---|---|
| D1 | Section forms threw `data is not defined` — no observation/event/session/reflection could be added | pass the loaded snapshot into `openForm` | create observation: PASS |
| D2 | Calendar overflowed 32px at 360px and 2px at 390px | `repeat(7, minmax(0,1fr))`, `min-width:0`, tighter gap under 380px | overflow: 0 |
| D3 | `.btn--sm` 36px and `.btn--xs`/segment 32px touch targets | minimum 44px on all interactive controls | small targets: 0 |
| D4 | `hidden` error boxes rendered as empty visible frames (settings) | `[hidden]{display:none!important}` | visible alerts: 0 |
| D5 | English never applied before a profile existed, so LTR was unreachable | `applyLang()` reads `?lang` and keeps it across navigation | dir mismatches: 0 |
| D6 | Harness fixture flag lost after `pushState`, silently hitting the network | flag captured once, stored in sessionStorage | 84/84 rows clean |

## 6. Explicitly out of scope and absent

PropDesk import · Expert Journal connection · EA push · broker integration · trading analytics ·
correlation · AI analysis · psychological scoring · signals · market prediction · notifications ·
social features · public profiles · any entity beyond the five.

`/insights` and `/trading` remain inert placeholders from Phase 1 and contain no logic.

## 7. Testing status

| Item | Status |
|---|---|
| Real backend CRUD on the deployed service | **PASS** (17/17) |
| Cascade delete and orphan prevention | **PASS** |
| UI layout / direction / targets / overflow, 5 widths | **PASS** (84/84) |
| UI interaction flows (fixture data) | **PASS** (9/9, harness-scoped) |
| Real signup/login/logout through the app UI | **NOT EXECUTED** |
| Data persistence across a real logout/login cycle | **NOT EXECUTED** |
| Cross-user isolation end to end | **NOT EXECUTED** |
| RLS on the five entities | **BLOCKED** (no platform control) |
| Android install / TWA | **NOT EXECUTED** (needs a physical device) |
