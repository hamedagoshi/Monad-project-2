# MONAD — Phase 1.5: Security Closure

Date: 2026-11-05 · Scope: close Phase 1.4 gaps · Status vocabulary: PASS / FAIL / NOT EXECUTED / BLOCKED

Nothing from Phase 1.1–1.4 was rebuilt. The delivered work is limited to verification,
documentation and the small fixes listed in §6.

## 1. Acceptance summary

| id | Item | Status | Evidence |
|---|---|---|---|
| A1 | Existing architecture preserved | PASS | `git`-level diff in §6; no route, entity or token was replaced |
| A2 | RLS enforced and verified on `UserProfile` | **BLOCKED** | No RLS control exists in the available toolset (see §2) |
| A2a | Anonymous direct Entity API access denied | PASS | `tests/evidence/entity-api-probe.txt`: GET/POST `/entities/UserProfile` → **403**, `/entities/DailyRecord` → **403** |
| A2b | Cross-user direct Entity API access denied | **NOT EXECUTED** | needs two real accounts (§4) |
| A3 | Real signup / login / logout | **NOT EXECUTED** | needs the owner's action on the hosted auth service |
| A3b | Session persistence / restoration / expiry (real session) | **NOT EXECUTED** | cannot mint a real platform session |
| A3c | Invalid session rejected | PASS | garbage bearer → 401 (`security/results-unauthenticated.json`) |
| A4 | Cross-user isolation through the function | **NOT EXECUTED** | one authenticated principal available |
| A4b | Cross-user isolation through direct Entity API | **NOT EXECUTED** | same |
| A5 | Token expiration evidence | **NOT EXECUTED** | an unsigned `exp`-past token proves signature rejection, not expiry |
| A6 | Bootstrap concurrency | PASS (bounded) + **NOT EXECUTED** (parallel) | idempotency and reconciliation pass; parallel authenticated requests not run |
| A6b | User preferences survive reconciliation | PASS | `en / light / Asia/Tehran` unchanged after 3 rows → 1 |
| A7 | Every test carries a status | PASS | this table |

No NOT EXECUTED or BLOCKED item is reported as PASS anywhere in this document.

## 2. RLS: what was checked and why it is BLOCKED

Checked, in this order:
1. `manage_entity_schemas` — accepts `name` + JSON Schema only; there is no access, policy,
   or RLS field, and an update returns the same schema unchanged.
2. The platform skill for entities (`data-entities`) — describes CRUD, pagination and that
   RLS exists as an *app setting*; it exposes no call to read or set it.
3. The deployed function — sees rows for the caller and never inspects policy.
4. Direct HTTP probe of the entity endpoint without credentials — 403 (see A2a).

Conclusion: the RLS *state* of `UserProfile` cannot be read or changed from this workspace.
It is an owner-only app-settings action. Therefore:

* I do **not** claim RLS is enabled.
* I do **not** claim the entity is fully isolated.
* The honest status is **BLOCKED**, with the documented risk in §3.

## 3. Blocking risk (stated plainly)

If RLS is disabled on the platform entity, an authenticated client holding a valid session
could call the entity REST/SDK API directly and read rows it does not own. The application
code cannot prevent that; only the platform policy can. This is recorded as risk **R1**.

Mitigations actually in place:
* All app reads and writes go through `monadProfile` / `monadJournal`, which derive the owner
  from the session and reject a foreign `owner_id` with 403.
* No client code queries these entities directly.
* The data stored is intentionally low-sensitivity (display name, language, timezone, theme,
  personal journal text). No credentials, no trading account data.

What the owner can do that I cannot: open app settings → `UserProfile` → enable owner-only
RLS. Until then the risk is open, not closed.

## 4. Why the real-authentication items are NOT EXECUTED

* Creating a second real account requires interacting with the hosted signup flow and
  confirming an email; I have no inbox control and no authorisation to create accounts.
* Session expiration needs a real session whose lifetime can be controlled; the platform
  issues those, not the sandbox.
* The routing double (`?test=1`) performs **no** authentication. It is a UI harness and was
  never used as evidence for any security row above.

## 5. Executed security evidence (re-confirmed in Phase 1.5)

| Test | Result |
|---|---|
| Unauthenticated read / update / delete | 401 ×3 |
| Invalid bearer | 401 |
| Forged `owner_id` with valid session | 403 `ownership_spoof_rejected` |
| Invalid enum, path traversal in `timezone` | 422 ×2 |
| Wrong method | 405 |
| CORS preflight | 200 |
| Delete with a foreign record id | 404 |
| Anonymous direct Entity API (4 verbs, 2 entities) | 403 ×5 |
| Bootstrap idempotency, duplicate reconciliation | 200, rows → 1 |

## 6. Changes made in this phase

| File | Change | Why |
|---|---|---|
| `app/js/app.js` | `applyLang()` honours `?lang` before a profile exists and keeps the choice across client-side navigation | English UI could never be reached before login, so the LTR requirement was not exercisable |
| `app/css/app.css` | added `[hidden] { display: none !important; }` | `hidden` error boxes were rendered as empty visible frames by component display rules |
| `app/js/fixtures.js` | flag captured once at module load | after the first `pushState` the query string disappears, so the harness silently fell back to the real network |
| No backend, entity or token change | — | Phase 1.4 logic is unchanged |

## 7. Remaining security risks

| id | Risk | Severity | Owner |
|---|---|---|---|
| R1 | RLS state unknown/unenforced on `UserProfile` (and the five Phase-2 entities) | **High** | Platform app settings |
| R2 | No DB unique index on `owner_id`; cross-isolate duplicate insert possible | Low | Platform |
| R3 | No rate limiting on either function | Low | Platform |
| R4 | Real signup/login/expiry and cross-user isolation unproven | Medium | Requires two real accounts |
