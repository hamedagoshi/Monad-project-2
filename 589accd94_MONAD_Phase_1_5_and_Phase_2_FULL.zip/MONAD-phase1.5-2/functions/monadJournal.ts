/**
 * monadJournal — Phase 2 Daily Experience service.
 *
 * One function owns all five Phase-2 collections. Every operation:
 *   1. derives the owner from the server-side session (never from the body),
 *   2. rejects a client-supplied owner_id that differs (403),
 *   3. verifies that a child's parent day is also owned by the caller,
 *   4. validates input against an allow-list,
 *   5. writes a secret-free audit line.
 *
 * Actions
 *   day.get {date} | day.upsert {date,title?,general_note?} | day.update {id,patch}
 *   day.delete {id,confirm} | day.list {from?,to?,limit?,offset?}
 *   obs.create|update|delete     event.create|update|delete
 *   session.create|update|delete reflection.create|update|delete
 *   timeline {from?,to?,limit?}  calendar {from,to}
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (body, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });

let SEQ = 0;
function audit(event, outcome, userId, extra = {}) {
  console.log(JSON.stringify({
    t: 'monad.journal', seq: ++SEQ, at: new Date().toISOString(),
    event, outcome, user: userId ? String(userId).slice(0, 8) : null, ...extra,
  }));
}

const DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
const ISO_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d{1,3})?)?(Z|[+-]\d{2}:\d{2})?$/;
const CATS = ['physical', 'mental', 'emotional', 'environmental', 'other'];

const isDay = (v) => typeof v === 'string' && DAY_RE.test(v) && !Number.isNaN(Date.parse(v + 'T00:00:00Z'));
const isIso = (v) => typeof v === 'string' && ISO_RE.test(v) && !Number.isNaN(Date.parse(v));
const str = (v, max) => (v === undefined || v === null ? '' : String(v).slice(0, max));
const opt = (v, max) => (v === undefined || v === null || String(v).trim() === '' ? '' : String(v).trim().slice(0, max));

/* ---------------------------------------------------------------- ownership */
async function ownedDays(base44, userId, query = {}) {
  const page = await base44.entities.DailyRecord.filter(
    { owner_id: userId, ...query }, { sort: '-record_date', limit: 100 },
  );
  return (page?.items ?? []).filter((r) => r.owner_id === userId);
}

async function dayById(base44, userId, id) {
  const page = await base44.entities.DailyRecord.filter({ id }, { limit: 1 });
  const row = (page?.items ?? [])[0];
  if (!row || row.owner_id !== userId) return null;
  return row;
}

async function children(base44, entity, dayId, userId) {
  const page = await base44.entities[entity].filter({ daily_record_id: dayId }, { limit: 200 });
  return (page?.items ?? []).filter((r) => r.owner_id === userId && r.daily_record_id === dayId);
}

async function childOwned(base44, entity, id, userId) {
  const page = await base44.entities[entity].filter({ id }, { limit: 1 });
  const row = (page?.items ?? [])[0];
  if (!row || row.owner_id !== userId) return null;
  return row;
}

/* ------------------------------------------------------------------ schemas */
const SPEC = {
  obs: { entity: 'StateObservation', order: 'observed_at' },
  event: { entity: 'LifeEvent', order: 'event_time' },
  session: { entity: 'TradingSession', order: 'start_time' },
  reflection: { entity: 'Reflection', order: 'created_date' },
};

function validate(kind, src, creating) {
  const errors = [];
  const out = {};
  const put = (k, v) => { if (v !== undefined) out[k] = v; };

  if (kind === 'event') {
    if (creating || 'title' in src) {
      const t = str(src.title, 120).trim();
      if (!t) errors.push('title is required');
      put('title', t);
    }
    if (creating || 'event_time' in src) {
      if (!isIso(src.event_time)) errors.push('event_time must be an ISO timestamp');
      put('event_time', src.event_time);
    }
    put('description', str(src.description, 2000));
    put('category', opt(src.category, 40));
  }

  if (kind === 'obs') {
    if (creating || 'state_category' in src) {
      if (!CATS.includes(src.state_category)) errors.push('state_category must be physical|mental|emotional|environmental|other');
      put('state_category', src.state_category);
    }
    if (creating || 'observed_at' in src) {
      if (!isIso(src.observed_at)) errors.push('observed_at must be an ISO timestamp');
      put('observed_at', src.observed_at);
    }
    if (creating || 'description' in src) {
      const d = str(src.description, 2000).trim();
      if (!d) errors.push('description is required');
      put('description', d);
    }
    if ('intensity' in src) {
      if (src.intensity === null || src.intensity === '') put('intensity', null);
      else {
        const n = Number(src.intensity);
        if (!Number.isFinite(n) || n < 1 || n > 5) errors.push('intensity must be between 1 and 5');
        else put('intensity', n);
      }
    }
  }

  if (kind === 'session') {
    if (creating || 'start_time' in src) {
      if (!isIso(src.start_time)) errors.push('start_time must be an ISO timestamp');
      put('start_time', src.start_time);
    }
    if ('end_time' in src) {
      if (src.end_time === null || src.end_time === '') put('end_time', '');
      else if (!isIso(src.end_time)) errors.push('end_time must be an ISO timestamp');
      else put('end_time', src.end_time);
    }
    if (creating && out.start_time && out.end_time && Date.parse(out.end_time) < Date.parse(out.start_time)) {
      errors.push('end_time must not precede start_time');
    }
    put('market', opt(src.market, 40));
    put('note', str(src.note, 2000));
  }

  if (kind === 'reflection') {
    if (creating || 'response' in src) {
      const r = str(src.response, 8000).trim();
      if (!r) errors.push('response is required');
      put('response', r);
    }
    put('question', opt(src.question, 300));
  }

  return { out, errors };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json({ ok: false, code: 'method_not_allowed' }, 405);

  const base44 = createClientFromRequest(req);

  let me = null;
  try { me = await base44.auth.me(); } catch (_) { me = null; }
  if (!me?.id) {
    audit('auth.verify', 'denied_unauthenticated', null);
    return json({ ok: false, code: 'unauthenticated' }, 401);
  }
  const userId = me.id;

  let body = {};
  try { body = await req.json(); } catch (_) { body = {}; }

  if (body.owner_id && String(body.owner_id) !== userId) {
    audit('authorization', 'denied_owner_mismatch', userId);
    return json({ ok: false, code: 'ownership_spoof_rejected' }, 403);
  }

  const action = String(body.action || '');

  try {
    /* -------------------------------------------------------------- day.get */
    if (action === 'day.get') {
      if (!isDay(body.date)) return json({ ok: false, code: 'invalid_date' }, 422);
      const rows = await ownedDays(base44, userId, { record_date: body.date });
      const record = rows[0] ?? null;
      if (!record) return json({ ok: true, record: null, observations: [], events: [], sessions: [], reflections: [] });
      const [observations, events, sessions, reflections] = await Promise.all([
        children(base44, 'StateObservation', record.id, userId),
        children(base44, 'LifeEvent', record.id, userId),
        children(base44, 'TradingSession', record.id, userId),
        children(base44, 'Reflection', record.id, userId),
      ]);
      return json({ ok: true, record, observations, events, sessions, reflections });
    }

    /* ----------------------------------------------------------- day.upsert */
    if (action === 'day.upsert') {
      if (!isDay(body.date)) return json({ ok: false, code: 'invalid_date' }, 422);
      const rows = await ownedDays(base44, userId, { record_date: body.date });
      const now = new Date().toISOString();
      if (rows.length) {
        const patch = {};
        if ('title' in body) patch.title = str(body.title, 120).trim();
        if ('general_note' in body) patch.general_note = str(body.general_note, 8000);
        patch.updated_at = now;
        const updated = await base44.entities.DailyRecord.update(rows[0].id, patch);
        audit('day.upsert', 'updated', userId);
        return json({ ok: true, record: updated, created: false });
      }
      const created = await base44.entities.DailyRecord.create({
        owner_id: userId,
        record_date: body.date,
        title: str(body.title, 120).trim(),
        general_note: str(body.general_note, 8000),
        created_at: now,
        updated_at: now,
      });
      audit('day.upsert', 'created', userId);
      return json({ ok: true, record: created, created: true });
    }

    /* ----------------------------------------------------------- day.update */
    if (action === 'day.update') {
      const row = await dayById(base44, userId, body.id);
      if (!row) { audit('day.update', 'not_found_or_foreign', userId); return json({ ok: false, code: 'not_found' }, 404); }
      const patch = { updated_at: new Date().toISOString() };
      if ('title' in body.patch || 'title' in body) patch.title = str(body.patch?.title ?? body.title, 120).trim();
      if ('general_note' in (body.patch ?? {}) || 'general_note' in body) {
        patch.general_note = str(body.patch?.general_note ?? body.general_note, 8000);
      }
      if ('record_date' in (body.patch ?? {})) {
        if (!isDay(body.patch.record_date)) return json({ ok: false, code: 'invalid_date' }, 422);
        const clash = await ownedDays(base44, userId, { record_date: body.patch.record_date });
        if (clash.some((r) => r.id !== row.id)) return json({ ok: false, code: 'date_conflict' }, 409);
        patch.record_date = body.patch.record_date;
      }
      const updated = await base44.entities.DailyRecord.update(row.id, patch);
      audit('day.update', 'ok', userId);
      return json({ ok: true, record: updated });
    }

    /* ----------------------------------------------------------- day.delete */
    if (action === 'day.delete') {
      const row = await dayById(base44, userId, body.id);
      if (!row) { audit('day.delete', 'not_found_or_foreign', userId); return json({ ok: false, code: 'not_found' }, 404); }
      if (body.confirm !== true) {
        audit('day.delete', 'confirmation_required', userId);
        return json({ ok: false, code: 'confirmation_required', children: await countChildren(base44, row.id, userId) }, 409);
      }
      const removed = await cascadeDelete(base44, row.id, userId);
      await base44.entities.DailyRecord.delete(row.id);
      audit('day.delete', 'deleted', userId, { children: removed });
      return json({ ok: true, deleted: row.id, children: removed });
    }

    /* ------------------------------------------------------------- day.list */
    if (action === 'day.list') {
      const query = {};
      if (isDay(body.from)) query.record_date = { $gte: body.from };
      const rows = await ownedDays(base44, userId, query);
      const filtered = rows
        .filter((r) => (isDay(body.from) ? r.record_date >= body.from : true))
        .filter((r) => (isDay(body.to) ? r.record_date <= body.to : true));
      return json({ ok: true, records: filtered, count: filtered.length });
    }

    /* ---------------------------------------------------- child create paths */
    const childMatch = action.match(/^(obs|event|session|reflection)\.(create|update|delete)$/);
    if (childMatch) {
      const [, kind, op] = childMatch;
      const { entity } = SPEC[kind];

      if (op === 'create') {
        const parent = await dayById(base44, userId, body.daily_record_id);
        if (!parent) {
          audit(`${kind}.create`, 'parent_not_owned', userId);
          return json({ ok: false, code: 'not_found' }, 404);
        }
        const { out, errors } = validate(kind, body, true);
        if (errors.length) return json({ ok: false, code: 'validation_failed', errors }, 422);
        const now = new Date().toISOString();
        const created = await base44.entities[entity].create({
          ...out,
          owner_id: userId,
          daily_record_id: parent.id,
          created_at: now,
          ...(kind === 'reflection' ? { updated_at: now } : {}),
        });
        audit(`${kind}.create`, 'ok', userId);
        return json({ ok: true, item: created });
      }

      if (op === 'update') {
        const row = await childOwned(base44, entity, body.id, userId);
        if (!row) { audit(`${kind}.update`, 'not_found_or_foreign', userId); return json({ ok: false, code: 'not_found' }, 404); }
        const { out, errors } = validate(kind, body, false);
        if (errors.length) return json({ ok: false, code: 'validation_failed', errors }, 422);
        if (kind === 'session' && out.end_time && out.start_time && Date.parse(out.end_time) < Date.parse(out.start_time)) {
          return json({ ok: false, code: 'validation_failed', errors: ['end_time must not precede start_time'] }, 422);
        }
        const updated = await base44.entities[entity].update(row.id, {
          ...out,
          ...(kind === 'reflection' ? { updated_at: new Date().toISOString() } : {}),
        });
        audit(`${kind}.update`, 'ok', userId);
        return json({ ok: true, item: updated });
      }

      const row = await childOwned(base44, entity, body.id, userId);
      if (!row) { audit(`${kind}.delete`, 'not_found_or_foreign', userId); return json({ ok: false, code: 'not_found' }, 404); }
      await base44.entities[entity].delete(row.id);
      audit(`${kind}.delete`, 'deleted', userId);
      return json({ ok: true, deleted: row.id });
    }

    /* -------------------------------------------------------------- timeline */
    if (action === 'timeline') {
      const limit = Math.min(Number(body.limit) || 100, 200);
      const inRange = (t) => (!isDay(body.from) || t >= body.from) && (!isDay(body.to) || t <= body.to + 'T23:59:59.999Z');
      const days = await ownedDays(base44, userId);
      const perDay = await Promise.all(days.map(async (d) => {
        const [obs, evs, ses, refs] = await Promise.all([
          children(base44, 'StateObservation', d.id, userId),
          children(base44, 'LifeEvent', d.id, userId),
          children(base44, 'TradingSession', d.id, userId),
          children(base44, 'Reflection', d.id, userId),
        ]);
        return { d, obs, evs, ses, refs };
      }));

      const feed = [];
      for (const { d, obs, evs, ses, refs } of perDay) {
        feed.push({ type: 'day', id: d.id, at: d.created_at || d.record_date + 'T00:00:00.000Z', date: d.record_date, title: d.title || '', excerpt: (d.general_note || '').slice(0, 120), record_id: d.id });
        obs.forEach((o) => feed.push({ type: 'observation', id: o.id, at: o.observed_at, date: d.record_date, title: o.state_category, excerpt: (o.description || '').slice(0, 120), record_id: d.id, category: o.state_category }));
        evs.forEach((e) => feed.push({ type: 'event', id: e.id, at: e.event_time, date: d.record_date, title: e.title || '', excerpt: (e.description || '').slice(0, 120), record_id: d.id }));
        ses.forEach((s) => feed.push({ type: 'session', id: s.id, at: s.start_time, date: d.record_date, title: s.market || 'session', excerpt: (s.note || '').slice(0, 120), record_id: d.id }));
        refs.forEach((r) => feed.push({ type: 'reflection', id: r.id, at: r.created_at || (d.record_date + 'T00:00:00.000Z'), date: d.record_date, title: r.question || 'reflection', excerpt: (r.response || '').slice(0, 120), record_id: d.id }));
      }
      const items = feed.filter((f) => inRange(f.at)).sort((a, b) => (a.at < b.at ? 1 : a.at > b.at ? -1 : 0)).slice(0, limit);
      return json({ ok: true, items, count: items.length });
    }

    /* -------------------------------------------------------------- calendar */
    if (action === 'calendar') {
      if (!isDay(body.from) || !isDay(body.to)) return json({ ok: false, code: 'invalid_range' }, 422);
      const days = await ownedDays(base44, userId);
      const inRange = days.filter((d) => d.record_date >= body.from && d.record_date <= body.to);
      const out = [];
      for (const d of inRange) {
        const [obs, evs, ses, refs] = await Promise.all([
          children(base44, 'StateObservation', d.id, userId),
          children(base44, 'LifeEvent', d.id, userId),
          children(base44, 'TradingSession', d.id, userId),
          children(base44, 'Reflection', d.id, userId),
        ]);
        out.push({
          date: d.record_date, record_id: d.id,
          counts: { observations: obs.length, events: evs.length, sessions: ses.length, reflections: refs.length },
          has_note: Boolean((d.general_note || '').trim()),
        });
      }
      return json({ ok: true, days: out });
    }

    return json({ ok: false, code: 'unknown_action' }, 400);
  } catch (e) {
    audit('request', 'server_error', userId, { action: action.slice(0, 40) });
    return json({ ok: false, code: 'server_error', message: String(e) }, 500);
  }
});

/* --------------------------------------------------------------- helpers */
async function countChildren(base44, dayId, userId) {
  const [a, b, c, d] = await Promise.all([
    children(base44, 'StateObservation', dayId, userId),
    children(base44, 'LifeEvent', dayId, userId),
    children(base44, 'TradingSession', dayId, userId),
    children(base44, 'Reflection', dayId, userId),
  ]);
  return { observations: a.length, events: b.length, sessions: c.length, reflections: d.length };
}

async function cascadeDelete(base44, dayId, userId) {
  const map = { StateObservation: 0, LifeEvent: 0, TradingSession: 0, Reflection: 0 };
  for (const entity of Object.keys(map)) {
    const rows = await children(base44, entity, dayId, userId);
    for (const r of rows) {
      try { await base44.entities[entity].delete(r.id); map[entity] += 1; } catch (_) { /* best effort */ }
    }
  }
  return map;
}
