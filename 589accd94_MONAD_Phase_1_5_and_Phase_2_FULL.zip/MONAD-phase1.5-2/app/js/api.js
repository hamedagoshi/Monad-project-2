import { Fixtures, fixturesEnabled } from './fixtures.js';

/* MONAD — profile API client (server derives ownership; never sends owner_id) */
const ENDPOINT = '/functions/monadProfile';

async function call(payload) {
  const res = await fetch(ENDPOINT, {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  let data = null;
  try { data = await res.json(); } catch (_) { data = null; }
  if (!res.ok || !data?.ok) {
    const err = new Error(data?.code || `http_${res.status}`);
    err.code = data?.code || `http_${res.status}`;
    err.status = res.status;
    err.fields = data?.errors || [];
    throw err;
  }
  return data;
}

export const ProfileApi = {
  bootstrap: () => call({ action: 'bootstrap' }),
  get: () => call({ action: 'get' }),
  update: (patch) => call({ action: 'update', patch }),
};


const JOURNAL = '/functions/monadJournal';

async function jcall(payload) {
  const res = await fetch(JOURNAL, {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  let data = null;
  try { data = await res.json(); } catch (_) { data = null; }
  if (!res.ok || !data?.ok) {
    const err = new Error(data?.code || ('http_' + res.status));
    err.code = data?.code || ('http_' + res.status);
    err.status = res.status;
    err.fields = data?.errors || [];
    err.children = data?.children || null;
    throw err;
  }
  return data;
}

const F = () => fixturesEnabled();
const fx = (name, args) => Fixtures[name](...args);

export const JournalApi = {
  dayGet: (date) => (F() ? fx('dayGet', [date]) : jcall({ action: 'day.get', date })),
  dayUpsert: (date, fields) => (F() ? fx('dayUpsert', [date, fields]) : jcall({ action: 'day.upsert', date, ...fields })),
  dayUpdate: (id, patch) => (F() ? fx('update', ['day', id, patch]) : jcall({ action: 'day.update', id, patch })),
  dayDelete: (id, confirm = false) => (F() ? fx('dayDelete', [id, confirm]) : jcall({ action: 'day.delete', id, confirm })),
  dayList: (opts = {}) => (F() ? fx('dayList', [opts]) : jcall({ action: 'day.list', ...opts })),
  create: (kind, fields) => (F() ? fx('create', [kind, fields]) : jcall({ action: kind + '.create', ...fields })),
  update: (kind, id, fields) => (F() ? fx('update', [kind, id, fields]) : jcall({ action: kind + '.update', id, ...fields })),
  remove: (kind, id) => (F() ? fx('remove', [kind, id]) : jcall({ action: kind + '.delete', id })),
  timeline: (opts = {}) => (F() ? fx('timeline', [opts]) : jcall({ action: 'timeline', ...opts })),
  calendar: (from, to) => (F() ? fx('calendar', [from, to]) : jcall({ action: 'calendar', from, to })),
};

/* ---------- date helpers: stored strings stay strings; display is tz-aware ---------- */
export function todayIn(tz) {
  try {
    return new Intl.DateTimeFormat('en-CA', { timeZone: tz || undefined }).format(new Date());
  } catch (_) {
    return new Date().toISOString().slice(0, 10);
  }
}

export function toIso(dateStr, timeStr = '00:00') {
  const d = new Date(`${dateStr}T${timeStr}:00`);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

export function fmtTime(iso, tz, lang = 'fa') {
  if (!iso) return '—';
  try {
    return new Intl.DateTimeFormat(lang === 'en' ? 'en-GB' : 'fa-IR', {
      timeZone: tz || undefined, hour: '2-digit', minute: '2-digit',
    }).format(new Date(iso));
  } catch (_) { return iso.slice(11, 16); }
}

export function fmtDate(day, lang = 'fa') {
  if (!day) return '—';
  try {
    return new Intl.DateTimeFormat(lang === 'en' ? 'en-GB' : 'fa-IR', {
      year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC',
    }).format(new Date(day + 'T00:00:00Z'));
  } catch (_) { return day; }
}
