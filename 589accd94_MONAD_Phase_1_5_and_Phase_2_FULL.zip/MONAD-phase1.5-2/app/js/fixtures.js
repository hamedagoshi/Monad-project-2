/* LOCAL-ONLY fixture store. Active only with ?test=1&fixtures=1 on localhost.
   It exists so UI layout can be reviewed without a session. It is NOT production
   data, NOT an authentication path, and must be deleted before release. */
const DAYS = [{ id: 'd1', record_date: '2026-11-05', title: 'روز اول', general_note: 'اولین ثبت واقعی روی سرویس مستقر. تمرکز روی فرآیند، نه نتیجه.', created_at: '2026-11-05T06:00:00.000Z' }];
const OBS = [{ id: 'o1', daily_record_id: 'd1', observed_at: '2026-11-05T05:45:00.000Z', state_category: 'mental', description: 'ذهن آرام بود، ولی توجه پراکنده شد.', intensity: 4 }];
const EVS = [{ id: 'e1', daily_record_id: 'd1', event_time: '2026-11-05T04:00:00.000Z', title: 'پیاده‌روی صبحگاهی', description: 'چهل دقیقه پیاده‌روی قبل از بازار.', category: 'health' }];
const SES = [{ id: 's1', daily_record_id: 'd1', start_time: '2026-11-05T04:30:00.000Z', end_time: '2026-11-05T07:30:00.000Z', market: 'XAUUSD', note: 'دو ورود، هر دو در ناحیه مشخص‌شده.' }];
const REF = [{ id: 'r1', daily_record_id: 'd1', question: 'امروز چه چیزی را باید می‌دیدم و ندیدم؟', response: 'به جای نتیجه، به فرآیند نگاه نکردم. فردا فقط اجرا را می‌سنجم.', created_at: '2026-11-05T12:00:00.000Z' }];

const KEY = 'monad.fixtures.store';
try {
  const saved = sessionStorage.getItem(KEY);
  if (saved) {
    const st = JSON.parse(saved);
    DAYS.splice(0, DAYS.length, ...(st.DAYS || DAYS));
    OBS.splice(0, OBS.length, ...(st.OBS || OBS));
    EVS.splice(0, EVS.length, ...(st.EVS || EVS));
    SES.splice(0, SES.length, ...(st.SES || SES));
    REF.splice(0, REF.length, ...(st.REF || REF));
  }
} catch (_) { /* ignore */ }
function persist() {
  try { sessionStorage.setItem(KEY, JSON.stringify({ DAYS, OBS, EVS, SES, REF })); } catch (_) { /* ignore */ }
}

const ok = (v) => Promise.resolve(v);
const notFound = () => Promise.reject(Object.assign(new Error('not_found'), { code: 'not_found' }));

export const Fixtures = {
  dayGet: (date) => {
    const record = DAYS.find((d) => d.record_date === date) || null;
    if (!record) return ok({ record: null, observations: [], events: [], sessions: [], reflections: [] });
    return ok({
      record,
      observations: OBS.filter((x) => x.daily_record_id === record.id),
      events: EVS.filter((x) => x.daily_record_id === record.id),
      sessions: SES.filter((x) => x.daily_record_id === record.id),
      reflections: REF.filter((x) => x.daily_record_id === record.id),
    });
  },
  dayUpsert: (date, fields) => {
    let r = DAYS.find((d) => d.record_date === date);
    if (!r) { r = { id: 'd' + (DAYS.length + 1), record_date: date, title: '', general_note: '', created_at: new Date().toISOString() }; DAYS.push(r); }
    if ('title' in fields) r.title = fields.title;
    if ('general_note' in fields) r.general_note = fields.general_note;
    persist();
    return ok({ record: r, created: false });
  },
  dayDelete: (id, confirm) => (confirm ? ok({ deleted: id }) : Promise.reject(Object.assign(new Error('confirmation_required'), {
    code: 'confirmation_required', children: { observations: 1, events: 1, sessions: 1, reflections: 1 },
  }))),
  dayList: () => ok({ records: [...DAYS].sort((a, b) => (a.record_date < b.record_date ? 1 : -1)) }),
  create: (kind, f) => {
    const map = { obs: OBS, event: EVS, session: SES, reflection: REF };
    const item = { id: kind + Date.now(), ...f };
    map[kind].push(item);
    persist();
    return ok({ item });
  },
  update: (kind, id, f) => {
    const map = { obs: OBS, event: EVS, session: SES, reflection: REF };
    const row = map[kind].find((x) => x.id === id);
    if (!row) return notFound();
    Object.assign(row, f);
    persist();
    return ok({ item: row });
  },
  remove: (kind, id) => {
    const map = { obs: OBS, event: EVS, session: SES, reflection: REF };
    const arr = map[kind];
    const i = arr.findIndex((x) => x.id === id);
    if (i < 0) return notFound();
    arr.splice(i, 1);
    persist();
    return ok({ deleted: id });
  },
  timeline: () => ok({
    items: [
      { type: 'reflection', id: 'r1', at: '2026-11-05T12:00:00.000Z', date: '2026-11-05', title: 'بازنگری', excerpt: 'به جای نتیجه، به فرآیند نگاه نکردم.' },
      { type: 'observation', id: 'o1', at: '2026-11-05T05:45:00.000Z', date: '2026-11-05', title: 'mental', excerpt: 'ذهن آرام بود، ولی توجه پراکنده شد.' },
      { type: 'session', id: 's1', at: '2026-11-05T04:30:00.000Z', date: '2026-11-05', title: 'XAUUSD', excerpt: 'دو ورود، هر دو در ناحیه مشخص‌شده.' },
      { type: 'event', id: 'e1', at: '2026-11-05T04:00:00.000Z', date: '2026-11-05', title: 'پیاده‌روی صبحگاهی', excerpt: 'چهل دقیقه پیاده‌روی قبل از بازار.' },
    ],
    count: 4,
  }),
  calendar: (from, to) => ok({
    days: DAYS.filter((d) => d.record_date >= from && d.record_date <= to).map((d) => ({
      date: d.record_date, record_id: d.id,
      counts: { observations: OBS.length, events: EVS.length, sessions: SES.length, reflections: REF.length },
      has_note: Boolean(d.general_note),
    })),
  }),
};

/* Read the flag once: after the first pushState the query string is gone. */
const FLAG = (() => {
  try {
    const local = /^(localhost|127\.0\.0\.1)$/.test(location.hostname);
    const q = new URLSearchParams(location.search).get('fixtures') === '1';
    if (local && q) sessionStorage.setItem('monad.fixtures.on', '1');
    return local && (q || sessionStorage.getItem('monad.fixtures.on') === '1');
  } catch (_) { return false; }
})();

export const fixturesEnabled = () => FLAG;
