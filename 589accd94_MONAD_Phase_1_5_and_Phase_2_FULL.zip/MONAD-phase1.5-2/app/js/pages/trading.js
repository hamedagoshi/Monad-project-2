import { placeholder } from './placeholder.js';
export default {
  title: 'معاملات',
  html() {
    return placeholder({
      title: 'معاملات',
      body: 'ورود داده‌های معاملاتی از ژورنال موجود در فاز ۳ انجام می‌شود.',
      phase: 'فاز بعدی',
    });
  },
};
