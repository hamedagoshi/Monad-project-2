/* Journal — chronological list of DailyRecords with a simple range filter. */
import { JournalApi, fmtDate, todayIn } from '../api.js';

const t = (lang, fa, en) => (lang === 'en' ? en : fa);
const esc = (v) => String(v ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export default {
  title: 'ژورنال',
  html({ lang }) {
    return `
    <section class="section-header">
      <h1 class="section-header__title">${t(lang, 'ژورنال', 'Journal')}</h1>
      <button class="btn btn--primary btn--sm" id="new-day">+ ${t(lang, 'روز جدید', 'New day')}</button>
    </section>
    <div class="seg" role="group" id="range" aria-label="${t(lang, 'بازه', 'Range')}">
      <button data-range="30" aria-pressed="true">${t(lang, '۳۰ روز', '30 days')}</button>
      <button data-range="90" aria-pressed="false">${t(lang, '۹۰ روز', '90 days')}</button>
      <button data-range="0" aria-pressed="false">${t(lang, 'همه', 'All')}</button>
    </div>
    <div id="list" class="stack"></div>`;
  },

  after(root, ctx) {
    const { lang, profile } = ctx;
    const list = root.querySelector('#list');
    let range = 30;

    const dayMs = 86400000;

    const render = (records) => {
      if (!records.length) {
        list.innerHTML = `<div class="card"><div class="state">
          <div class="state__icon">□</div>
          <div class="state__title">${t(lang, 'هنوز روزی ثبت نشده', 'No days yet')}</div>
          <div class="state__body">${t(lang, 'هر روز، یک مشاهده. با یک روز شروع کن.', 'Every day, one observation. Start with today.')}</div>
          <button class="btn btn--primary btn--sm state__action" id="start-today">${t(lang, 'ثبت امروز', 'Record today')}</button>
        </div></div>`;
        const b = root.querySelector('#start-today');
        if (b) b.onclick = () => ctx.navigate('/day/' + todayIn(profile?.timezone));
        return;
      }
      list.innerHTML = records.map((r) => `
        <a class="card card--row" href="/day/${r.record_date}" data-link>
          <div>
            <div class="entry__title">${esc(r.title || fmtDate(r.record_date, lang))}</div>
            <div class="t-caption">${(r.general_note || '').slice(0, 70) || t(lang, 'بدون یادداشت', 'No note')}</div>
          </div>
          <span class="badge num">${r.record_date.slice(5)}</span>
        </a>`).join('');
    };

    async function load() {
      list.innerHTML = `<div class="skeleton skeleton--text"></div><div class="skeleton skeleton--text" style="width:60%"></div>`;
      const from = range ? todayIn(profile?.timezone) : undefined;
      try {
        const data = await JournalApi.dayList({});
        let records = data.records || [];
        if (range) {
          const cutoff = new Date(Date.now() - range * dayMs).toISOString().slice(0, 10);
          records = records.filter((r) => r.record_date >= cutoff);
        }
        render(records);
      } catch (e) {
        list.innerHTML = `<div class="alert alert--negative">${e.code === 'unauthenticated'
          ? t(lang, 'نشست منقضی شده است.', 'Session expired.')
          : t(lang, 'بارگذاری نشد.', 'Could not load.')}</div>`;
      }
      void from;
    }

    root.querySelectorAll('[data-range]').forEach((b) => {
      b.onclick = () => {
        range = Number(b.dataset.range);
        root.querySelectorAll('[data-range]').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
        load();
      };
    });

    root.querySelector('#new-day').onclick = () => ctx.navigate('/day/' + todayIn(profile?.timezone));
    load();
  },
};
