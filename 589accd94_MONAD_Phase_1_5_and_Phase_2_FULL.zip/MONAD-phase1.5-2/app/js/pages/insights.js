import { placeholder } from './placeholder.js';
export default {
  title: 'بینش',
  html() {
    return placeholder({
      title: 'بینش',
      body: 'تحلیل‌ها فقط روی داده‌های واقعی و پس از فاز ۲ معنا پیدا می‌کنند.',
      phase: 'فاز بعدی',
    });
  },
};
