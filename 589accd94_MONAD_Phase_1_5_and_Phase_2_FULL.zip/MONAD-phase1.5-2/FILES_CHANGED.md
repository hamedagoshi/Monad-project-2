# Files changed — Phase 1.5 + Phase 2

## Created
| Path | Purpose |
|---|---|
| `functions/monadJournal.ts` | server-side service for all five Phase-2 entities |
| `app/js/pages/day.js` | `/day/:date` — five independent sections, CRUD, cascade delete |
| `app/js/pages/journal.js` | chronological list + range filter + empty state |
| `app/js/pages/home.js` | rewritten: today's status, counts, latest entries |
| `app/js/pages/timeline.js` | rewritten: real merged feed |
| `app/js/pages/calendar.js` | rewritten: real month grid, marked days, day selection |
| `app/js/fixtures.js` | local-only fixture store for the UI harness (guarded, removable) |
| `app/tests/ui-harness.html` | 84-combination sweep + 9 interaction flows |
| `app/tests/seed3.html`, `app/tests/dbg-obs.html` | harness helpers |
| `tests/evidence/ui-harness-raw.json` | raw harness output |
| `tests/evidence/entity-api-probe.txt` | anonymous Entity API status codes |
| `tests/evidence/shots/*.png` | 7 screenshots (390 dark RTL, 390 light, 1280 light LTR) |
| `security/SECURITY.md`, `security/results-unauthenticated.json`, `security/run_unauth_tests.py` | Phase 1.4 evidence (unchanged) |
| `PHASE_1_5_REPORT.md`, `PHASE_2_REPORT.md`, `FILES_CHANGED.md` | this phase's reports |

## Modified
| Path | Change |
|---|---|
| `app/js/api.js` | `JournalApi` client, date/timezone helpers, fixture routing under a local-only guard |
| `app/js/router.js` | parameterised routes (`:date`) |
| `app/js/app.js` | `/day/:date` route; `applyLang()` honours `?lang` |
| `app/css/app.css` | entry, inline form, calendar, `[hidden]`, 44px targets, overflow guards |
| Entity schemas | `created_at` / `updated_at` added to the five Phase-2 entities |
| `app/REPORT.md` | Phase 1.4 section appended (earlier content preserved) |

## Deleted
Nothing. Every artifact from Phase 1.1–1.4 is intact.

## Entity relationships
`UserProfile` → (owner) → `DailyRecord` → 1:N → `StateObservation`, `LifeEvent`,
`TradingSession`, `Reflection`. `LifeEvent.daily_record_id` is optional; the other three
children require a parent. All parent links are ownership-checked server-side.
